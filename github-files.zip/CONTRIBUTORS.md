# 🏆 Přispěvatelé

Děkujeme všem, kteří přispěli k tomuto projektu!

## 👑 Hlavní autoři

<table>
  <tr>
    <td align="center">
      <a href="https://github.com/EmperorKunDis">
        <img src="https://github.com/EmperorKunDis.png" width="100px;" alt="Martin Švanda"/><br />
        <sub><b>Martin Švanda</b></sub>
      </a><br />
      <sub>Autor & Maintainer</sub>
    </td>
  </tr>
</table>

## 💻 Přispěvatelé kódu

<!-- ALL-CONTRIBUTORS-LIST:START -->
<!-- Bude automaticky generováno -->
*Zatím žádní další přispěvatelé. Buďte první!*
<!-- ALL-CONTRIBUTORS-LIST:END -->

## 📝 Přispěvatelé dokumentace

*Zatím žádní přispěvatelé dokumentace.*

## 🎨 Přispěvatelé designu

*Zatím žádní přispěvatelé designu.*

## 🌍 Překladatelé

*Zatím žádní překladatelé.*

---

## Jak se dostat na tento seznam?

Přispějte do projektu jakýmkoliv způsobem:

- 🐛 Nahlaste nebo opravte bug
- ✨ Přidejte novou funkci
- 📝 Vylepšete dokumentaci
- 🎨 Navrhněte design vylepšení
- 🌍 Pomozte s překladem
- 💬 Odpovídejte na otázky v issues

Každý příspěvek se počítá! 🙏

---

<sub>Tento seznam je spravován pomocí [All Contributors](https://allcontributors.org/) specifikace.</sub>
